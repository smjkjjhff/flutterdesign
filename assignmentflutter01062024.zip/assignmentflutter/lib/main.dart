import 'package:assignmentflutter/screens/cooper_plan.dart';
import 'package:assignmentflutter/screens/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:assignmentflutter/screens/chat_screen.dart';
import 'package:assignmentflutter/constants/colorcode.dart';
// import 'package:device_preview/device_preview.dart';

void main() {
  runApp(
    MyApp(),
  );
}
// void main() {
//   runApp(
//     DevicePreview(
//       enabled: !bool.fromEnvironment('dart.vm.product'), // Enabled only in debug mode
//       builder: (context) => MyApp(), // Wrap your app with DevicePreview
//     ),
//   );
// }



class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // locale: DevicePreview.locale(context), // Add the locale here
      // builder: DevicePreview.appBuilder, // Add the builder here
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/chat': (context) => ChatScreen(),
        '/plans': (context) => CooperPlansScreen(),
      },
    );
  }
}





class CustomPopupMenuItem<T> extends PopupMenuItem<T> {
  final IconData icon;
  final VoidCallback onTap;
  final Color color;

  CustomPopupMenuItem({
    required this.icon,
    required this.onTap,
    required this.color,
  }) : super(
    child: Container(
      padding: EdgeInsets.all(8),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
            ),
            child: Center(
              child: Icon(
                icon,
                color: Colors.white,
              ),
            ),
          ),
          SizedBox(width: 8),
          Text(
            "",
            style: TextStyle(color: Colors.white),
          ),
        ],
      ),
    ),
    onTap: onTap,
  );
}

class MyWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: PopupMenuButton<String>(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(20)),
            ),
            color: Colors.black, // Custom background color for the popup
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              CustomPopupMenuItem(
                icon: Icons.mic,
                color: Colors.black, // Grey background color
                onTap: () {
                  // Handle audio selection
                },
              ),
              CustomPopupMenuItem(
                icon: Icons.image,
                color: Colors.black, // Grey background color
                onTap: () {
                  // Handle image selection
                },
              ),
              CustomPopupMenuItem(
                icon: Icons.video_call,
                color: Colors.black, // Grey background color
                onTap: () {
                  // Handle video selection
                },
              ),
            ],
            child: Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.black, // Adjusted color to match the design
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.add, color: Colors.white), // Adjusted color to match the design
            ),
          ),
        ),
      ),
    );
  }
}



