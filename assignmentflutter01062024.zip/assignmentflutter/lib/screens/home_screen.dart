import 'package:assignmentflutter/constants/colorcode.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(Icons.downloading_rounded, size: 40),
                      SizedBox(width: 10),
                      Text(
                        "Cooper 1.7",
                        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  GestureDetector(
                    onTap: () {
                      showMenu(
                        context: context,
                        position: RelativeRect.fromLTRB(100, 100, 0, 0), // Adjust position as needed
                        items: [
                          PopupMenuItem<String>(
                            value: 'Cooper+ Plan Pro',
                            child: Text('Cooper+ Plan Pro'),
                          ),
                        ],
                      ).then((value) {
                        if (value == 'Cooper+ Plan Pro') {
                          Navigator.pushNamed(context, '/plans');
                        }
                      });
                    },
                    child: Icon(Icons.keyboard_arrow_down, size: 24.0, color: Colors.black),
                  ),
                  CircleAvatar(
                    child: Icon(Icons.person, size: 40),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Text(
                "Hello James",
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                "Make your day easy with us",
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
              SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pushNamed(context, '/chat');
                      },
                      child: Container(
                        padding: EdgeInsets.all(24.0), // Increased padding to enlarge the card
                        decoration: BoxDecoration(
                          color: ColorCode.flutterColor2,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start, // Aligns content to the left
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.grey,
                                shape: BoxShape.circle,
                              ),
                              padding: EdgeInsets.all(5), // Adds padding to give a radius effect
                              child: Icon(Icons.mic, size: 30),
                            ),
                            SizedBox(height: 85), // Adjusted height
                            Text(
                              "Talk with Cooper",
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "Let's try it now",
                              style: TextStyle(fontSize: 16, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      children: [
                        Stack(
                          clipBehavior: Clip.none, // Allow overflow to show "New" text outside the card
                          children: [
                            GestureDetector(
                              onTap: () {
                                Navigator.pushNamed(context, '/chat');
                              },
                              child: Container(
                                padding: EdgeInsets.all(24.0), // Increased padding to enlarge the card
                                decoration: BoxDecoration(
                                  color: ColorCode.color8,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start, // Aligns content to the left
                                  children: [
                                    Icon(Icons.chat, size: 30),
                                    SizedBox(height: 20),
                                    Text(
                                      "New chat",
                                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              right: -10, // Adjusted to position half outside the card
                              top: -10,  // Adjusted to position half outside the card
                              child: Container(
                                padding: EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.red,
                                  shape: BoxShape.circle,
                                ),
                                child: Text(
                                  "New",
                                  style: TextStyle(fontSize: 12, color: Colors.white),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        GestureDetector(
                          onTap: () {
                            Navigator.pushNamed(context, '/chat');
                          },
                          child: Container(
                            padding: EdgeInsets.all(24.0), // Increased padding to enlarge the card
                            decoration: BoxDecoration(
                              color: Colors.black,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start, // Aligns content to the left
                              children: [
                                Icon(Icons.image_search, size: 30, color: Colors.white),
                                SizedBox(height: 10),
                                Text(
                                  "Search by image",
                                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 30),
              Text(
                "Recent Search",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Column(
                children: [
                  _buildRecentSearchItem("What is a wild animal?", Icons.mic, ColorCode.flutterColor2),
                  _buildRecentSearchItem("Scanning images", Icons.image_search, Colors.black),
                  _buildRecentSearchItem("Analysis my dribble shot", Icons.analytics, ColorCode.flutterColor6),
                  _buildRecentSearchItem("How to show the prototype in Figma", Icons.mic, ColorCode.flutterColor2),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRecentSearchItem(String title, IconData icon, Color backgroundColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child
          :
      Container(
        padding: EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          color: ColorCode.color3,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(8.0),
              decoration: BoxDecoration(
                color: backgroundColor, // Set the background color here
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 24.0, color: Colors.white),
            ),
            SizedBox(width: 10),
            Expanded(child: Text(title, style: TextStyle(fontSize: 18))),
            Icon(Icons.more_horiz),
          ],
        ),
      ),
    );
  }
}
