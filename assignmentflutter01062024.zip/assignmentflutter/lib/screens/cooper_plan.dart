import 'package:assignmentflutter/constants/colorcode.dart';
import 'package:flutter/material.dart';

class CooperPlansScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: ColorCode.flutterColor5, // Adjust the background color as needed
                    ),
                    child: IconButton(
                      icon: Icon(Icons.arrow_back),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),
                ],
              ),
              SizedBox(height: 16),
              Center(
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.black,
                      child: Icon(Icons.downloading_rounded, color: Colors.white, size: 40),
                    ),
                    SizedBox(height: 8),
                    Text(
                      "Cooper+ plans",
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    Text(
                      "Try unlimited features with cooper+",
                      style: TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 24),
              PlanCard(
                title: "Monthly Plan",
                price: "            \$8.99/month",
                style: TextStyle(fontSize: 16,color: ColorCode.flutterColor8),

                color: ColorCode.flutterColor7,
                iconColor: ColorCode.color1,
              ),
              SizedBox(height: 16),

              PlanCard(
                title: "Yearly Plan",
                price: "          \$8.99/month",
                // Add spaces before the price
                style: TextStyle(fontSize: 16, color: Colors.grey), // This style applies to other parts of the card, not the price
                color: ColorCode.flutterColor6,
                iconColor: ColorCode.color2,
              ),

              SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                  padding: EdgeInsets.symmetric(vertical: 16),
                ),
                child: Text(

                  "Subscription",
                  style: TextStyle(fontSize: 16,color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PlanCard extends StatelessWidget {
  final String title;
  final String price;
  final Color color;
  final Color iconColor;

  const PlanCard({
    required this.title,
    required this.price,
    required this.color,
    required this.iconColor,
    required TextStyle style,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: iconColor,
                child: Icon(Icons.circle, color: Colors.white),
              ),
              SizedBox(width: 8),
              Text(
                title,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Spacer(),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Text(
                    "Free ads",
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 2),
          Text(
            price,
            style: TextStyle(fontSize: 16, color: Colors.grey), // Apply custom style to the price
          ),
          SizedBox(height: 8),
          Divider(color: Colors.grey), // Add divider after the price
          SizedBox(height: 8), // Add additional space after the divider
          Row(
            children: [
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: Colors.black,
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.check, color: Colors.white),
              ),
              SizedBox(width: 8),
              Text("Chat unlimited"),
              SizedBox(width: 16), // Add space between the two rows
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: Colors.black,
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.check, color: Colors.white),
              ),
              SizedBox(width: 8),
              Text("Notify automatic"),
            ],
          ),
        ],
      ),
    );
  }
}
