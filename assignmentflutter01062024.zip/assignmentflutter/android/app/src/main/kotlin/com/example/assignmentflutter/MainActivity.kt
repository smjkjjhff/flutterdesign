package com.example.assignmentflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
